# backjoon-2108
최빈값,중앙값,범위
