﻿//#include <iostream>
//using namespace std;
//
//int main()
//{
//	long long arr[101] = { 0, };
//	arr[1] = 1;
//	arr[2] = 1;
//	arr[3] = 1;
//	arr[4] = 2;
//	arr[5] = 2;
//	for (int i = 6; i <= 100; i++)
//	{
//		arr[i] = arr[i - 5] + arr[i - 1];
//	}
//
//	int t;
//	cin >> t;
//	int n;
//	for (int i = 0; i < t; i++)
//	{
//		cin >> n;
//		cout << arr[n] << '\n';
//	}
//
//
//
//
//	return 0;
//}

#include <iostream>
using namespace std;


long long arr[1000001] = { 0, };

int main()
{
	
	arr[1] = 1;
	arr[2] = 2;
	for (int i = 3; i <= 1000000; i++)
	{
		arr[i] = arr[i - 1]%15746 + arr[i - 2]%15746;
	}

	int n;
	cin >> n;
	cout << arr[n]%15746 << '\n';

	return 0;
}