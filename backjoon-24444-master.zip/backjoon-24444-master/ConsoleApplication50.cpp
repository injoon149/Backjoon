﻿#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;


vector<vector<int>> v(100001, vector<int>());
vector<int> visited(100001, 0);
queue<int> q;
int k = 0;
int seq = 0;


void BFS(int r);

int main()
{
	int n, m, r;
	cin >> n >> m >> r;
	int a, b;
	for (int i = 0; i < m; i++)
	{
		cin >> a >> b;
		v[a].push_back(b);
		v[b].push_back(a);
	}
	for (int i = 1; i <= n; i++)
	{
		sort(v[i].begin(), v[i].end());
	}
	BFS(r);
	for (int i = 1; i < n + 1; i++)
	{
		cout << visited[i] << '\n';
	}
	



	return 0;
}

void BFS(int r)
{
	visited[r] = ++seq;
	q.push(r);
	while (!q.empty())
	{
		int u = q.front();
		q.pop();
		for (auto iter = v[u].begin(); iter != v[u].end(); iter++)
		{
			if (visited[*iter] == 0) {
				visited[*iter] = ++seq;
				q.push(*iter);
			}
		}
	}
}