﻿#include <iostream>
#include <map>
#include <string>
using namespace std;

int main()
{
	int t;
	cin >> t;
	string a, b;
	
	for (int i = 0; i < t; i++)
	{
		int n;
		cin >> n;
		int count = 1;
		map<string, int> m;
		for (int j = 0; j < n; j++)
		{
		
			cin >> a >> b;
			m[b]++;
		}
		for (auto iter = m.begin(); iter != m.end(); iter++)
		{
			count = count * (iter->second + 1);
		}
		cout << count - 1 << '\n';
	}

	return 0;
}