﻿#include <iostream>
#include <vector>
using namespace std;

bool visited[101];
vector<vector<int>> v(101, vector<int>());
int countt = 0;

void DFS(int r) {
	visited[r] = true;
	countt++;
	for (int i = 0; i < v[r].size(); i++)
	{
		if (visited[v[r][i]] == false)
		{
			DFS(v[r][i]);
		}
	}
}

int main()
{
	int n;
	cin >> n;
	int b;
	cin >> b;
	int c, d;
	for (int i = 0; i < b; i++)
	{
		cin >> c >> d;
		v[c].push_back(d);
		v[d].push_back(c);
	}

	DFS(1);

	cout << countt - 1;

	return 0;
}