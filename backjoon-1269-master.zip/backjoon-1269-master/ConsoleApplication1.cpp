﻿#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int array1[200001] = { 0, };
int array2[200001] = { 0, };

int main()
{
	cin.tie(NULL);

	cout.tie(NULL);

	ios::sync_with_stdio(false);
	int a, b;
	int num = 0;
	vector<int> v1;
	vector<int> v2;
	cin >> a >> b;
	for (int i = 0; i < a; i++)
	{
		cin >> array1[i];
	}
	for (int i = 0; i < a; i++)
	{
		v1.push_back(array1[i]);
		
	}
	for (int i = 0; i < b; i++)
	{
		cin >> array2[i];
	}
	for (int i = 0; i < b; i++)
	{
		v2.push_back(array2[i]);
	}
	sort(v1.begin(), v1.end());
	sort(v2.begin(), v2.end());
	for (int i = 0; i < v1.size(); i++)
	{
		if (binary_search(v2.begin(), v2.end(), v1.at(i)) == 1)
		{
			num++;
		}
	}
	cout << a + b - 2*num;

	return 0;
	
}