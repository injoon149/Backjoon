﻿//프린터 큐
#include <iostream>
#include <queue>
using namespace std;

int main()
{
	int t, n, m;
	cin >> t;
	int array[101] = { 0, };

	
	for (int i = 0; i < t; i++)
	{
		queue<pair<int, int>> q;
		priority_queue<int> pq;
		int count = 0;
		cin >> n >> m;
		for (int j = 0; j < n; j++)
		{
			cin >> array[j];
			q.push({ j, array[j] });
			pq.push(array[j]);
			
		}

		while(!q.empty())
		{
			//q의 맨 앞이 pq의 맨 앞과 동일할 때(잘 정렬됬을 때) 
			if (q.front().second == pq.top())
			{
				//내가 찾는 그 원소인지 파악, 맞으면 count 리턴
				if (q.front().first == m)
				{
					cout << count+1 << '\n';
					break;
				}
				//틀리면 그래도 잘 정렬된 거니까 q와 pq 둘 다 pop을 한다.
				else
				{
					q.pop();
					pq.pop();
					count++;
				}

			}
			//큐가 정렬 자체가 안되있으니까 문제에 나와있는대로 큐의 front만 빼서 다시 push 한다.
			else {
				pair<int,int> top = q.front();
				q.pop();
				q.push(top);
			}
		}
	}


	return 0;
	
}