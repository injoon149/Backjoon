# backjoon-1966
우선순위 큐 사용
