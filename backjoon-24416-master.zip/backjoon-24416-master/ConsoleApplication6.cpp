﻿#include <iostream>
using namespace std;


int cnt1 = 0;
int fib(int n)
{
	if (n == 1 || n == 2) {
		cnt1++;
		return 1;
	}
	else return fib(n - 1) + fib(n - 2);
}

int main()
{
	int array[40] = { 0, };
	int n = 0;
	int cnt2 = 0;
	cin >> n;
	fib(n);
	cout << cnt1 << '\n';

	array[1] = 1;
	array[2] = 1;
	for (int i = 3; i <= n; i++)
	{
		cnt2++;
		array[i] = array[i - 1] + array[i - 2];

	}
	cout << cnt2;
}