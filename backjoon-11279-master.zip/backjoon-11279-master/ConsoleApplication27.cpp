﻿#include <iostream>
#include <queue>
using namespace std;

int main()
{
	cin.tie(NULL);
	cout.tie(NULL);
	ios::sync_with_stdio(false);
	int n;
	cin >> n;
	int num;
	priority_queue<int> pq;
	for (int i = 0; i < n; i++)
	{
		cin >> num;
		if (num == 0)
		{
			if (pq.empty())
			{
				cout << "0" << '\n';
			}
			else {
				cout << pq.top() << '\n';
				pq.pop();
			}
		}
		else
		{
			pq.push(num);
		}
	}

	return 0;

}