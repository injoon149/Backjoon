# backjoon-10815
stl-binary search 이용한 프로그램
