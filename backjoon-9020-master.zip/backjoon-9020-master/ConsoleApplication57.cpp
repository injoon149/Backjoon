﻿#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	cin.tie(NULL);
	ios::sync_with_stdio(false);


	int maxval = 10001;
	bool* prime_list = new bool[maxval];
	fill_n(prime_list, maxval + 1, true);
	prime_list[1] = false;

	for (int i = 2; i <= sqrt((double)maxval); i++)
	{
		if (prime_list[i] == true)
		{
			for (int j = i * 2; j <= 10001; j += i)
			{
				prime_list[j] = false;
			}
		}
	}

	int t;
	cin >> t;
	for (int i = 0; i < t; i++)
	{
		int n;
		cin >> n;
		for (int j = n/2; j <= n; j++)
		{
			if ((prime_list[j] == true) && (prime_list[n-j] == true))
			{
				cout << n-j<< " " << j << '\n';
				break;
			}
		}
	}

	return 0;
	



}


