# backjoon-9020
fill_n, 소수활용(골드바흐의 추측)
