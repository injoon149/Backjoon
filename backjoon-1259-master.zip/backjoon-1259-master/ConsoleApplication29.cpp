﻿#include <iostream>
#include <string>
using namespace std;

void palindrome(string s)
{
	int flag = 0;
	if (s.size() % 2 == 0)
	{
		for (int i = 0; i < s.size()/2; i++)
		{
			if (s[i] == s[s.size() - i-1])
			{
				flag = 0;
			}
			else {
				cout << "no" << '\n';
				return;
			}
		}
	}
	else
	{
		for (int i = 0; i < s.size(); i++)
		{
			if (s[i] == s[s.size() - i - 1])
			{
				flag = 0;
			}
			else {
				cout << "no" << '\n';
				return;
			}
		}
	}
	if (flag == 0)
	{
		cout << "yes" << '\n';
	}

}


int main()
{
	string s;
	cin >> s;
	while (s != "0")
	{
		palindrome(s);
		cin >> s;
	}

	return 0;
}