﻿#include <iostream>
#include <queue>
#include <cmath>
#include <algorithm>
#include <vector>
using namespace std;

struct MyFunctor {
	bool operator()(int a, int b) const
	{
		if (abs(a) == abs(b))
		{
			return a > b;
		}
		else
		{
			return abs(a) > abs(b);
		}
	}
};

int main()
{

	int n;
	cin >> n;
	int x;
	priority_queue<int, vector<int>, MyFunctor> pq;
	for (int i = 0; i < n; i++)
	{
		cin >> x;
		if (x == 0)
		{
			if (pq.empty())
			{
				cout << "0" << '\n';
			}
			else
			{
				cout << pq.top() << '\n';
				pq.pop();
			}
		}
		else
		{
			pq.push(x);
		}
	}

	return 0;
}