﻿#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

vector<vector<int>> v(1001, vector<int>());
bool visited[1001] = { false, };
vector<int> bvisited(1001, 0);
queue<int> q;
int seq = 0;

void DFS(int r);
void BFS(int r);

int main()
{
	int n, m, r;
	cin >> n >> m >> r;
	int a, b;

	for (int i = 0; i < m; i++)
	{
		cin >> a >> b;
		v[a].push_back(b);
		v[b].push_back(a);
	}
	for (int i = 1; i <= n; i++)
	{
		sort(v[i].begin(), v[i].end());
	}
	DFS(r);
	cout << '\n';
	BFS(r);

	


	return 0;
}

void DFS(int r)
{
	visited[r] = true;
	cout << r << " ";
	for (int i = 0; i < v[r].size(); i++)
	{
		if (visited[v[r][i]] == false)
		{
			DFS(v[r][i]);
		}
	}

}

void BFS(int r)
{
	bvisited[r] = ++seq;
	cout << r << " ";
	q.push(r);
	while (!q.empty())
	{
		int u = q.front();
		q.pop();
		for (auto iter = v[u].begin(); iter != v[u].end(); iter++)
		{
			if (bvisited[*iter] == 0)
			{
				bvisited[*iter] = ++seq;
				cout << *iter << " ";
				q.push(*iter);
			}
		}
	}
}