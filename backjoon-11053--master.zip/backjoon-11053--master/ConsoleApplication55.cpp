﻿#include <iostream>
#include <vector>
using namespace std;

int main()
{
	int n;
	cin >> n;
	vector<int> v(1001, 0);
	int dp[1001] = { 0, };
	for (int i = 1; i <= n; i++)
	{
		cin >> v[i];
	}

	for (int i = 1; i <= n; i++)
	{
		dp[i] = 1;
		for (int j = i - 1; j > 0; j--)
		{
			if (v[i] > v[j])
			{
				dp[i] = max(dp[i], dp[j] + 1);
			}
		}
	}

	int length = 0;
	for (int i = 1; i <= n; i++)
	{
		if (dp[i] > length)
		{
			length = dp[i];
		}
	}

	cout << length;

	return 0;
}