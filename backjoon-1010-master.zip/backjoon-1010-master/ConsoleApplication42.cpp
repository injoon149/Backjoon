﻿#include <iostream>
using namespace std;

int arr[31][31] = { 0, };

int main()
{
	int t;
	cin >> t;
	int n, m;
	
	for (int i = 1; i <= 30; i++)
	{
		arr[1][i] = i;
	}
	for (int i = 2; i <= 30; i++)
	{
		for (int j = 2; j <= 30; j++)
		{
			for (int k = 1; k < j; k++)
			{
				arr[i][j] += arr[i - 1][k];
			}
		}
	}
	for (int i = 0; i < t; i++)
	{
		cin >> n >> m;
		cout << arr[n][m] << '\n';
		
	}

	return 0;
}