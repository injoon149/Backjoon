﻿#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main()
{
	vector<int> v;
	int n;
	cin >> n;
	v.assign(n + 1, -1);
	v[1] = 0;
	for (int i = 2; i <= n; i++)
	{
		int tmp = v[i - 1] + 1;
		if (i % 2 == 0)
		{
			tmp = min(v[i / 2] + 1, tmp);
		}
		if (i % 3 == 0)
		{
			tmp = min(v[i / 3] + 1, tmp);
		}
		v[i] = tmp;
	}

	cout << v[n];

	return 0;


}