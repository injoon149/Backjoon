﻿#include <iostream>
#include <vector>
using namespace std;

int main()
{
	int n;
	cin >> n;
	int a;
	vector<int> v;
	vector<int> answer;
	for (int i = 0; i < n; i++)
	{
		cin >> a;
		v.push_back(a);
	}
	
	vector<int> memo(n, 0);
	memo[0] = v[0];
	memo[1] = v[0] + v[1];
	memo[2] = v[2] + max(v[0], v[1]);
	for (int i = 3; i < n; i++)
	{
		memo[i] = v[i] + max((memo[i - 3] +v[i - 1]), memo[i - 2]);
	}

	cout << memo[n-1];



}