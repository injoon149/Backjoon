# backjoon-1874
스택 수열(스택 이용)
