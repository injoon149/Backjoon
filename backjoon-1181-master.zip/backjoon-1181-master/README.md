# backjoon-1181
구조체와 sort의 조화 사용. flag 기법 사용.
