﻿#include <iostream>
#include <numeric>
using namespace std;

//int gcd(int n, int m)
//{
//	int gcd = 1;
//	for (int k = 1; k <= n && k <= m; k++)
//	{
//		if (n % k == 0 && m % k == 0)
//		{
//			gcd = k;
//		}
//	}
//	return gcd;
//}


int main()
{
	int arr[101] = { 0, };
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> arr[i];
	}
	for (int i = 0; i < n - 1; i++)
	{
		int divisor = gcd(arr[0], arr[i + 1]);
		int numer = arr[0] / divisor;
		int denom = arr[i + 1] / divisor;
		cout << numer << "/" << denom << '\n';
	}

	return 0;
}