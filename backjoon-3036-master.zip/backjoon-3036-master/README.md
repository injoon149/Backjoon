# backjoon-3036
최대공약수(구현, stl 활용)
