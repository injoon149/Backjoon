# backjoon-10816
upper_bound, lower_bound 이용
