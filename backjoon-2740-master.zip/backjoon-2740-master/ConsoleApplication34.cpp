﻿#include <iostream>
#include <vector>
using namespace std;

int main()
{
	int n, m;
	cin >> n >> m;
	vector<vector<int>> v1(n, vector<int>(m, 0));
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			cin >> v1[i][j];
		}
	}

	int a, b;
	cin >> a >> b;
	vector<vector<int>> v2(a, vector<int>(b, 0));
	for (int i = 0; i < a; i++)
	{
		for (int j = 0; j < b; j++)
		{
			cin >> v2[i][j];
		}
	}

	

	vector<vector<int>> v3(n, vector<int>(b, 0));
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < b; j++)
		{
			for (int k = 0; k < a; k++)
			{
				v3[i][j] += (v1[i][k] * v2[k][j]);
			}
		
		}
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < b; j++)
		{
			cout << v3[i][j] << " ";
		}
		cout << '\n';
	}

	return 0;

}